package com.reusable.basic;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.usermodel.DataFormatter;



public class ReadExcelData {
	

	static String filePath=null;
	
	

	
	
	public static String getValue(String sheet, String columnName, int rowNumber) {
		
		String value = null;
		String result = null;
		
		
		
			filePath="./testdata/testdata.xlsx";
	
		
		
		try
		{
			
			DataFormatter formatter = new DataFormatter();
			Workbook wb = WorkbookFactory.create(new FileInputStream((new File(filePath))));
		
			int columnMax = wb.getSheet(sheet).getRow(0).getLastCellNum();
		
			for(int i = 0; i < columnMax; i++) 
			{
				
				value = formatter.formatCellValue(wb.getSheet(sheet).getRow(0).getCell(i));
				if(columnName.equals(value)) 
				{
					System.out.println("Column number : "+i +" Row number : "+rowNumber);					
					result = formatter.formatCellValue(wb.getSheet(sheet).getRow(rowNumber).getCell(i));
					System.out.println("Value from excel is "+result);
					break;
				}
			}
		
		}
		catch(EncryptedDocumentException e)
		{
			e.printStackTrace();
		}
		catch(InvalidFormatException e)
		{
			e.printStackTrace();
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		return result;
	}
	
public static String getNumber(String sheet, String columnName, int rowNumber) {
		
		String value = null;
		String result = null;
		
		//////////
	
		
			filePath="./testdata/WriteData.xlsx";
		
		
		///////
		
		
		try
		{
			
			DataFormatter formatter = new DataFormatter();
			Workbook wb = WorkbookFactory.create(new FileInputStream((new File(filePath))));
		
			int columnMax = wb.getSheet(sheet).getRow(0).getLastCellNum();
		
			for(int i = 0; i < columnMax; i++) 
			{
				
				value = formatter.formatCellValue(wb.getSheet(sheet).getRow(0).getCell(i));
				if(columnName.equals(value)) 
				{
					System.out.println("Column number : "+i +" Row number : "+rowNumber);					
					result = formatter.formatCellValue(wb.getSheet(sheet).getRow(rowNumber).getCell(i));
					System.out.println("Value from excel is "+result);
					break;
				}
			}
		
		}
		catch(EncryptedDocumentException e)
		{
			e.printStackTrace();
		}
		catch(InvalidFormatException e)
		{
			e.printStackTrace();
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		return result;
	}
	
	

}
