package com.reusable.basic;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Method;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;


public class Generic {
	
	public WebDriver driver; 
	public static int rowCount;
	public static String testCaseName = null;
	
	@BeforeMethod
	public void setUp()
	{
		String browserName = GetPropertyValue.getValue("browser");
		System.out.println(browserName);
		if(browserName.equalsIgnoreCase("firefox"))
		{
			
			System.setProperty("webdriver.gecko.driver","./exefolder/geckodriver.exe");
			driver=new FirefoxDriver();
			Reporter.log("Firefox browser launched",true);
		}
		else if(browserName.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver","./exefolder/chromedriver.exe");
			
			ChromeOptions options = new ChromeOptions();
			options.addArguments("disable-notifications");
			
			
			driver = new ChromeDriver(options);
			//driver=new ChromeDriver();
			Reporter.log("Chrome browser launched", true);
			driver.manage().window().maximize();
			
		}
		WaitStatement.iWaitForSecs(driver,20);
		driver.navigate().to(GetPropertyValue.getValue("url"));
		Reporter.log("url Navigated", true);
		
	}
///////////////////////////////////////////////////////////////////////////////////////////	
	
	@BeforeMethod
	public void nameBefore(Method method)
	{
		
		int count;
		int row= 0;

	    System.out.println("TestCase name: " + method.getName());   
	    
	    testCaseName = method.getName();
	    
	    final String filePath="./testdata/testdata.xlsx";
	    try {
			Workbook wb = WorkbookFactory.create(new FileInputStream((new File(filePath))));
			 count = wb.getSheet("Sheet1").getPhysicalNumberOfRows();
			
			
	
			 for (int j = 1; j < count; j++) {
				 
			String testCaseName= wb.getSheet("Sheet1").getRow(j).getCell(0).getStringCellValue();
			    	
			
			    	
			    	 if (testCaseName.equalsIgnoreCase(method.getName())) {

                          row = j;

                         System.out.println("line number is " + row);

                         break;

                     }
			    	 
			    }
      
		


			
		} catch (EncryptedDocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	   
          rowCount =row;

	    


	}

        
                    

	
	
/////////////////////////////////////////////////////////////////////////////////////	
	@AfterMethod
	public void tearDown(ITestResult result)
	{
		String scriptName = result.getMethod().getMethodName();
		if(result.isSuccess())    //true
		{
			Reporter.log(scriptName+" script is passed",true);   //We can also use SOP
		}
		else
		{
			// false--> fail
			System.out.println( scriptName+" script failed");
			ScreenshotLib slib=new ScreenshotLib();
			slib.takeScreenshot(driver, scriptName);
			Reporter.log("Screenshot has been taken", true);
		}
	//	driver.close();
		Reporter.log("Browser is closed",true);
	}


}
