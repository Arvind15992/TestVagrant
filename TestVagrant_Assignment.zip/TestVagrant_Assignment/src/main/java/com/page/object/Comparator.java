package com.page.object;

import org.testng.Assert;

public class Comparator {
	
	int diff;
	public void  compareTemp(int tempWeb , int tempApi) 
	{
		
		
		
		if (tempWeb>tempApi) {
					
			diff= tempWeb-tempApi;
					
		}
				
		if (tempWeb<tempApi) {
							
			diff= tempApi-tempWeb;
						
		 }
		
		if(diff<=3) {
			
			System.out.println("Temp in range");
			
		}
		else {
			
			Assert.assertEquals(1, 2);
		}
		
		
		
	}

}
