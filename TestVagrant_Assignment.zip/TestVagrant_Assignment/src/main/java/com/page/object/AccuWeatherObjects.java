package com.page.object;


import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.reusable.basic.ReadExcelData;
import com.reusable.basic.WaitStatement;

public class AccuWeatherObjects {
	
	WebDriver driver;
	
	
	
	@FindBy(xpath= "//input[@placeholder='Search Location']")
	static WebElement enterCity;
	
	
	
	@FindBy(xpath= "//span[@class='header-temp']")
	static WebElement temperature;
	
	public AccuWeatherObjects(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	

	
	public int getWeatherOfAnyCity(String testCaseName , int rowCount) {
		
		
		
		enterCity.sendKeys(ReadExcelData.getValue("Sheet1", "city", rowCount));
		WaitStatement.hardWait(3);
		enterCity.click();
		enterCity.sendKeys(Keys.ARROW_DOWN, Keys.ENTER);
		WaitStatement.iWaitForSecs(driver, 15);
		WaitStatement.hardWait(5);
		String temp =	temperature.getText();
		temp= 	temp.toString().replaceAll("[^0-9 ]", "").replaceAll(" +", " ").trim();
		System.out.println("web temp-------" +temp);
		int webTemp = Integer.parseInt(temp)+ 273;
		System.out.println("web-------" +webTemp);
		
		return webTemp;
		
		
		

		
		
		
	}
	

}
