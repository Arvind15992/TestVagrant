package com.page.object;

import static io.restassured.RestAssured.given;

import java.util.HashMap;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class OpenWeatherMap {
	
	public  int getCityTemp(String city) 
	
	{
		
		HashMap<String , String> hash =  new HashMap<String, String>();
		hash.put("q", city);
		hash.put("appid", "7fe67bf08c80ded756e598d6f8fedaea" );
		RequestSpecification req = new RequestSpecBuilder().setBaseUri("https://api.openweathermap.org").setContentType(ContentType.JSON).build();
		
		ResponseSpecification responseSpec = new ResponseSpecBuilder().build();
		
		
		RequestSpecification res = given().log().all().spec(req).queryParameters(hash);
		String response = res.when().get("/data/2.5/weather").andReturn().then().spec(responseSpec).log().all().extract().response().asString();
	    String temp = JsonPath.from(response).getString("main.temp");
	    float f=Float.parseFloat(temp); 
	    int apiTemp  =(int)f;
	
	    System.out.println("api-------" +apiTemp);
	
	
	   return apiTemp;
		
	}

}
