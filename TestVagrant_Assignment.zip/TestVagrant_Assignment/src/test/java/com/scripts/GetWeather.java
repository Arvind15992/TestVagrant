package com.scripts;

import org.testng.annotations.Test;

import com.page.object.AccuWeatherObjects;
import com.page.object.Comparator;
import com.page.object.OpenWeatherMap;
import com.reusable.basic.Generic;
import com.reusable.basic.ReadExcelData;


public class GetWeather extends Generic {
	
	
AccuWeatherObjects weather;
OpenWeatherMap apiWeather;
Comparator compare;
	
	@Test
	public void getWeather() {
		
				
		weather = new AccuWeatherObjects(driver);
		int webTemp = weather.getWeatherOfAnyCity(testCaseName, rowCount);
		
		apiWeather = new OpenWeatherMap();
		int apiTemp = apiWeather.getCityTemp(ReadExcelData.getValue("Sheet1", "city", rowCount));
		
		compare = new Comparator();
		compare.compareTemp(webTemp, apiTemp); 
	
		
		
	}

}
